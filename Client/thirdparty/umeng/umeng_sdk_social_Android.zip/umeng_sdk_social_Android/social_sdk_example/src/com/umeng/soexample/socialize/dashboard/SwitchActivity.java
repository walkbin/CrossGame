package com.umeng.soexample.socialize.dashboard;

import java.util.Set;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;

import com.umeng.socom.Log;
import com.umeng.soexample.socialize.fragments.CommentFragment;
import com.umeng.soexample.socialize.fragments.OtherFragment;
import com.umeng.soexample.socialize.fragments.ShareFragment;
import com.umeng.ui.BaseSinglePaneActivity;

public class SwitchActivity extends BaseSinglePaneActivity {
	public static final int FLAG_SHARE_DEMO = 0;
	public static final int FLAG_COMMENT_DEMO = 1;
	public static final int FLAG_OTHER_DEMO = 2;

	public static final String FLAG_KEY = "flag_key";

	private int flag = -1;


	private Fragment content = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		flag = getIntent().getExtras().getInt(FLAG_KEY, -1);
		super.onCreate(savedInstanceState);

	}

	@Override
	protected Fragment onCreatePane() {
		switch (flag) {
		case FLAG_SHARE_DEMO:
			content = new ShareFragment();
			break;
		case FLAG_COMMENT_DEMO:
			content = new CommentFragment();
			break;
		case FLAG_OTHER_DEMO:
			content = new OtherFragment();
			break;
		}

		return content;
	}

	@Override
	protected void onActivityResult(int arg0, int arg1, Intent arg2) {
		super.onActivityResult(arg0, arg1, arg2);
		String result = "null";
		try {
			Bundle b = arg2.getExtras();
			Set<String> keySet = b.keySet();
			if(keySet.size() > 0)
				result = "result size:"+keySet.size();
			for(String key : keySet){
				Object object = b.get(key);
				Log.d("TestData", "Result:"+key+"   "+object.toString());
			}
		}
		catch (Exception e) {

		}
		Log.d("TestData", "onActivityResult   " + arg0 + "   " + arg1 + "   " + result);
	}


}
