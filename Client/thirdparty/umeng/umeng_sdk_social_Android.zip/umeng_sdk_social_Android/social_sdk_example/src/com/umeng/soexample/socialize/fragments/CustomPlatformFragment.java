package com.umeng.soexample.socialize.fragments;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.Toast;

import com.tencent.mm.sdk.openapi.BaseReq;
import com.tencent.mm.sdk.openapi.BaseResp;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.IWXAPIEventHandler;
import com.tencent.mm.sdk.openapi.SendAuth;
import com.tencent.mm.sdk.openapi.SendAuth.Req;
import com.tencent.mm.sdk.openapi.SendMessageToWX;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.tencent.mm.sdk.openapi.WXMediaMessage;
import com.tencent.mm.sdk.openapi.WXWebpageObject;
import com.tencent.mm.sdk.platformtools.Util;
import com.umeng.socialize.bean.CustomPlatform;
import com.umeng.socialize.bean.SocializeConfig;
import com.umeng.socialize.controller.RequestType;
import com.umeng.socialize.controller.UMServiceFactory;
import com.umeng.socialize.controller.UMSocialService;
import com.umeng.socialize.controller.listener.SocializeListeners.OnCustomPlatformClickListener;
import com.umeng.socialize.media.UMImage;
import com.umeng.socialize.media.UMediaObject;
import com.umeng.socialize.media.UMediaObject.MediaType;
import com.umeng.socialize.view.ActionBarView;
import com.umeng.soexample.R;
import com.umeng.soexample.socialize.SocialDemoConfig;

public class CustomPlatformFragment extends Fragment {
	private static final int THUMB_SIZE = 150;
	public IWXAPI api;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		api = WXAPIFactory.createWXAPI(getActivity(), "wx92e468cd3f047396");
		View root = inflater.inflate(	R.layout.umeng_example_socialize_customplatform_example,
										container,
										false);

		api.handleIntent(getActivity().getIntent(), new IWXAPIEventHandler() {
			@Override
			public void onResp(BaseResp arg0) {
				SendAuth.Resp resp = (SendAuth.Resp) arg0;
				System.out.println(resp.userName);
			}

			@Override
			public void onReq(BaseReq arg0) {}
		});

		String des = "Weixin";
		SocializeConfig mConfig = SocialDemoConfig.getSocialConfig(getActivity());
		// 创建自定义平台微信
		CustomPlatform mWXPlatform = new CustomPlatform("微信", R.drawable.weixin_icon);

		mWXPlatform.clickListener = new OnCustomPlatformClickListener() {
			@Override
			public void onClick(CustomPlatform customPlatform,
								String shareContent,
								UMediaObject shareImage) {
				if (!api.isWXAppInstalled()) {
					Toast.makeText(getActivity(), "你还没有安装微信", Toast.LENGTH_SHORT).show();
					return;
				} else if (!api.isWXAppSupportAPI()) {
					Toast.makeText(getActivity(), "你安装的微信版本不支持当前API", Toast.LENGTH_SHORT).show();
					return;
				}

				boolean sendReq = sendByWX(api, shareContent, shareImage, false);

				Toast.makeText(	getActivity(),
								"#" + sendReq + "[WX]  " + shareContent == null ? "" : shareContent,
								Toast.LENGTH_SHORT)
						.show();
			}

		};
		// 创建自定义平台微信朋友圈
		CustomPlatform mWXCircle = new CustomPlatform("朋友圈", R.drawable.wxcircel);
		mWXCircle.clickListener = new OnCustomPlatformClickListener() {
			@Override
			public void onClick(CustomPlatform customPlatform,
								String shareContent,
								UMediaObject shareImage) {
				if (!api.isWXAppInstalled()) {
					Toast.makeText(getActivity(), "你还没有安装微信", Toast.LENGTH_SHORT).show();
					return;
				} else if (!api.isWXAppSupportAPI()) {
					Toast.makeText(getActivity(), "你安装的微信版本不支持当前API", Toast.LENGTH_SHORT).show();
					return;
				}

				boolean sendReq = sendByWX(api, shareContent, shareImage, true);

				Toast.makeText(	getActivity(),
								"#" + sendReq + "[Circle]  " + shareContent == null	? ""
																					: shareContent,
								Toast.LENGTH_SHORT).show();
			}
		};
		// 添加自定义平台到Entity
		mConfig.addCustomPlatform(mWXPlatform);
		mConfig.addCustomPlatform(mWXCircle);

		UMSocialService controller = UMServiceFactory.getUMSocialService(des, RequestType.SOCIAL);
		controller.setConfig(mConfig);
		controller.setShareContent("自定义平台集成Demo测试");
		UMImage shImage = new UMImage(getActivity(), R.drawable.testimg);
		controller.setShareImage(shImage);

		// 用于集成ActionBar 的ViewGroup
		ViewGroup parent = (ViewGroup) root.findViewById(R.id.root);
		// 创建ActionBar des参数是ActionBar的唯一标识，请确保不为空
		ActionBarView socializeActionBar = new ActionBarView(getActivity(), des);

		LayoutParams layoutParams = new ViewGroup.LayoutParams(	LayoutParams.WRAP_CONTENT,
																LayoutParams.FILL_PARENT);
		socializeActionBar.setLayoutParams(layoutParams);
		// 添加ActionBar
		parent.addView(socializeActionBar);

		// 通过微信授权获取相关信息
		root.findViewById(R.id.weixin_auth).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				SendAuth.Req req = new Req();
				req.scope = "post_timeline";
				req.state = "none";
				api.sendReq(req);
			}
		});

		return root;
	}

	private String buildTransaction(final String type) {
		return (type == null)	? String.valueOf(System.currentTimeMillis())
								: type + System.currentTimeMillis();
	}

	private boolean sendByWX(	final IWXAPI api,
								String shareContent,
								UMediaObject shareImage,
								boolean toCircle) {
		WXWebpageObject webpage = new WXWebpageObject();
		webpage.webpageUrl = "http://www.umeng.com";
		WXMediaMessage msg = new WXMediaMessage(webpage);
		msg.title = "这是一个神奇的团队。";
		msg.description = shareContent;

		if (shareImage != null && shareImage.getUrlType() == MediaType.IMAGE) {
			byte[] b = shareImage.toByte();
			if (b != null) {
				Bitmap bmp = BitmapFactory.decodeByteArray(b, 0, b.length);
				Bitmap thumbBmp = Bitmap.createScaledBitmap(bmp, THUMB_SIZE, THUMB_SIZE, true);
				bmp.recycle();
				msg.thumbData = Util.bmpToByteArray(thumbBmp, true); // 设置缩略图
			}
		}

		SendMessageToWX.Req req = new SendMessageToWX.Req();
		req.transaction = buildTransaction("webpage");
		req.message = msg;
		req.scene = toCircle ? SendMessageToWX.Req.WXSceneTimeline
							: SendMessageToWX.Req.WXSceneSession;
		boolean sendReq = api.sendReq(req);
		return sendReq;
	}

}
