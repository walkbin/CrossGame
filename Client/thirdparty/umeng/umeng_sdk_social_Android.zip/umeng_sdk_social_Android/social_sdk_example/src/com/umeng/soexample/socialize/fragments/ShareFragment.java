package com.umeng.soexample.socialize.fragments;

import static com.umeng.soexample.socialize.SocialDemoConfig.DESCRIPTOR;

import java.util.Map;
import java.util.Set;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Toast;

import com.tencent.mm.sdk.platformtools.Log;
import com.umeng.socialize.bean.MultiStatus;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.bean.SocializeConfig;
import com.umeng.socialize.bean.SocializeEntity;
import com.umeng.socialize.bean.UMShareMsg;
import com.umeng.socialize.controller.RequestType;
import com.umeng.socialize.controller.UMInfoAgent;
import com.umeng.socialize.controller.UMServiceFactory;
import com.umeng.socialize.controller.UMSocialService;
import com.umeng.socialize.controller.listener.SocializeListeners.DirectShareListener;
import com.umeng.socialize.controller.listener.SocializeListeners.MulStatusListener;
import com.umeng.socialize.controller.listener.SocializeListeners.OauthCallbackListener;
import com.umeng.socialize.controller.listener.SocializeListeners.SnsPostListener;
import com.umeng.socialize.controller.listener.SocializeListeners.SocializeClientListener;
import com.umeng.socialize.exception.SocializeException;
import com.umeng.socialize.media.UMImage;
import com.umeng.socialize.media.UMVedio;
import com.umeng.socialize.media.UMusic;
import com.umeng.soexample.R;
import com.umeng.soexample.socialize.SocialDemoConfig;

public class ShareFragment extends Fragment {

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View root = inflater.inflate(	R.layout.umeng_example_socialize_sharemod_example,
										container,
										false);
		final Context mContext = getActivity();
		final SHARE_MEDIA testMedia = SHARE_MEDIA.SINA;

		BitmapDrawable drawable = (BitmapDrawable) mContext.getResources()
															.getDrawable(R.drawable.meiyu);
		Bitmap bitmap = drawable.getBitmap();

		final UMSocialService controller = UMServiceFactory.getUMSocialService(	DESCRIPTOR,
																				RequestType.SOCIAL);
		final String shareContent = "友盟致力于为中国的开发者提供专业的移动应用统计分析工具、实用组件以及推广服务。为开发者创造价值，是我们最大的价值。";
		controller.setShareContent(shareContent);
		UMImage shareImage = new UMImage(mContext, "http://historyhots.com/uploadfile/2013/0110/20130110064307373.jpg");
		UMusic uMusic = new UMusic("http://sns.whalecloud.com/test_music.mp3");
		uMusic.setAuthor("zhangliyong");
		uMusic.setTitle("天籁之音");
		UMVedio umVedio = new UMVedio("http://v.youku.com/v_show/id_XNTE5ODAwMDM2.html?f=19001023");
		controller.setShareMedia(shareImage);

		/********************************************* 设置授权完成后马上添加一个好友 **************************/
		final SocializeConfig config = SocialDemoConfig.getSocialConfig(getActivity());
		config.addFollow(testMedia, "1914100420");
		config.setOauthDialogFollowListener(new MulStatusListener() {
			@Override
			public void onStart() {
				Log.d("TestData", "Follow Start");
			}

			@Override
			public void onComplete(MultiStatus multiStatus, int st, SocializeEntity entity) {
				if (st == 200) {
					Map<String, Integer> allChildren = multiStatus.getAllChildren();
					Set<String> set = allChildren.keySet();
					for (String fid : set)
						Log.d("TestData", fid + "    " + allChildren.get(fid));
				}
			}
		});
		controller.setConfig(config);
		/*********************************************************************************************************/

		final View shareBt = root.findViewById(R.id.share_bt);
		final Handler handler = new Handler();
		shareBt.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				shareBt.setClickable(false);// 防止次点击出现多次对话框
				controller.openShare(mContext, false);
				handler.postDelayed(new Runnable() {
					@Override
					public void run() {
						shareBt.setClickable(true);
					}
				}, 1000);
			}
		});

		root.findViewById(R.id.direct_share_bt).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				DirectShareListener directShareListener = new DirectShareListener() {
					@Override
					public void onOauthComplete(String usid, SHARE_MEDIA platform) {
						if (!TextUtils.isEmpty(usid)) {
							// 授权成功（可打开分享页）
							Toast.makeText(mContext, "授权成功【usid:" + usid + "】", Toast.LENGTH_SHORT)
									.show();
						} else {
							// 授权失败（不可打开分享页）
							Toast.makeText(mContext, "授权失败,请重试！", Toast.LENGTH_LONG).show();
						}
					}

					@Override
					public void onAuthenticated(SHARE_MEDIA platform) {
						// 已经授权，直接打开分享页
						Toast.makeText(mContext, "已授权，直接打开。", Toast.LENGTH_SHORT).show();
					}
				};
				controller.directShare(mContext, testMedia, directShareListener);
			}
		});

		root.findViewById(R.id.interface_share_bt).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// 构建分享内容
				UMShareMsg shareMsg = new UMShareMsg();
				// 设置分享文字
				shareMsg.text = shareContent;
				controller.postShare(mContext, testMedia, shareMsg, new SnsPostListener() {
					@Override
					public void onStart() {
						Toast.makeText(mContext, "开始分享.", Toast.LENGTH_SHORT).show();
					}

					@Override
					public void onComplete(SHARE_MEDIA platform, int eCode, SocializeEntity entity) {
						if (eCode == 200) {
							Toast.makeText(mContext, "分享成功.", Toast.LENGTH_SHORT).show();
						} else {
							String eMsg = "";
							if (eCode == -101)
								eMsg = "没有授权";

							Toast.makeText(	mContext,
											"分享失败[" + eCode + "] " + eMsg,
											Toast.LENGTH_SHORT).show();
						}
					}
				});
			}
		});

		root.findViewById(R.id.interface_oauth).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (UMInfoAgent.isOauthed(mContext, testMedia)) {
					Toast.makeText(mContext, "新浪平台已经授权.", 1).show();
				} else {
					controller.doOauthVerify(mContext, testMedia, new OauthCallbackListener() {
						@Override
						public void onError(SocializeException e, SHARE_MEDIA platform) {

						}

						@Override
						public void onComplete(Bundle value, SHARE_MEDIA platform) {
							if (value != null && !TextUtils.isEmpty(value.getString("uid"))) {
								Toast.makeText(mContext, "授权成功.", Toast.LENGTH_SHORT).show();
							} else {
								Toast.makeText(mContext, "授权失败", Toast.LENGTH_SHORT).show();
							}
						}

					});
				}
			}
		});

		root.findViewById(R.id.quick_share).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				UMServiceFactory.shareTo(	getActivity(),
											SHARE_MEDIA.SINA,
											"我使用了快速分享接口（UMServiceFactory.share）分享该微博",
											null);
			}
		});

		root.findViewById(R.id.interface_deleteoauth).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				controller.deleteOauth(mContext, testMedia, new SocializeClientListener() {
					@Override
					public void onStart() {
						Log.d("TestData", "sina=" + UMInfoAgent.isOauthed(mContext, testMedia));

					}

					@Override
					public void onComplete(int status, SocializeEntity entity) {
						Log.d(	"TestData",
								status + "      sina=" + UMInfoAgent.isOauthed(mContext, testMedia));
					}
				});
			}
		});
		root.findViewById(R.id.share_multi_bt).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				 UMShareMsg shareMsg = new UMShareMsg();
				 shareMsg.text = shareContent;
				
				 controller.postShareMulti( mContext,
				 shareMsg,
				 new MulStatusListener() {
				 @Override
				 public void onStart() {
				 Toast.makeText( mContext,
				 "开始分享.",
				 Toast.LENGTH_SHORT).show();
				 }
				
				 @Override
				 public void onComplete( MultiStatus snsSt,
				 int st,
				 SocializeEntity entity) {
				 Toast.makeText( mContext,
				 snsSt.toString(),
				 Toast.LENGTH_LONG).show();
				 }
				 },
				 SHARE_MEDIA.SINA,
				 SHARE_MEDIA.RENREN,
				 SHARE_MEDIA.DOUBAN,
				 SHARE_MEDIA.TENCENT,
				 SHARE_MEDIA.QZONE);
			}
		});

		return root;
	}


}
