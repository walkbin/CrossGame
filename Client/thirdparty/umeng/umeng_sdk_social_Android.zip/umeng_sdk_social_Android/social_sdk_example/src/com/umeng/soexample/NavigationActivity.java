package com.umeng.soexample;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class NavigationActivity extends DropActivity  {

	private int meId_setting = -1;
	protected SlideMenu slidemenu;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	    slidemenu = new SlideMenu(this){
	    	@Override
	    	public void show() {
	    		onSlideMenuShow(slidemenu);
	    		super.show();
	    	}
	    	
	    	@Override
	    	public void hide() {
	    		onSlideMenuHide(slidemenu);
	    		super.hide();
	    	}
	    	@Override
	    	public void fillContent(View menu) {
	    		NavigationActivity.this.fillMenuContent(menu);
	    	}
	    };
	    slidemenu.checkEnabled();
	    actionBar.setIcon(R.drawable.umeng_example_socialize_action_icon);
		
	}
	
	@Override
	protected void onPageChanged(int pos) {
		if(pos > 0){
			actionBar.setDisplayHomeAsUpEnabled(true);
		}else
			actionBar.setDisplayHomeAsUpEnabled(false);

	}
	
	protected void fillMenuContent(View menu) {
	}
	protected void onSlideMenuShow(SlideMenu slidemenu) {
	}
	protected void onSlideMenuHide(SlideMenu slidemenu) {
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuItem settingItem = menu.add("Action Button");
		settingItem.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
		settingItem.setIcon(R.drawable.umeng_socialize_example_setting);
		meId_setting = settingItem.getItemId();
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if(android.R.id.home == item.getItemId()){
			mViewPager.setCurrentItem(0, true);
		}else if(item.getItemId() == meId_setting){
			if(slidemenu.isShow())
				slidemenu.hide();
			else
				slidemenu.show();
		}
		return true;
	}
	
	@Override
	public void onBackPressed() {
		if (slidemenu.isShow()) {
			slidemenu.hide();
		} else {
			finish();
		}
	}
	
}
