package com.umeng.soexample.socialize;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import android.content.Context;

import com.umeng.socialize.bean.APP_PLATFORM;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.bean.SocializeConfig;
import com.umeng.socialize.controller.RequestType;
import com.umeng.socialize.controller.UMServiceFactory;
import com.umeng.socialize.controller.UMSocialService;

public class SocialDemoConfig {
	public static boolean SUPPORT_SINA = true;
	public static boolean SUPPORT_RENR = true;
	public static boolean SUPPORT_DOUBAN = true;
	public static boolean SUPPORT_QZONE = true;
	public static boolean SUPPORT_TENC = true;
	
	public static boolean SUPPORT_FACEBOOK = true;
	public static boolean SUPPORT_TWITTER = true;
	public static boolean SUPPORT_GOOGLE = true;

	public static final String DESCRIPTOR = "android_test";

	private static final Set<WeakReference<SocializeConfig>> wCigs = new HashSet<WeakReference<SocializeConfig>>();

	/**
	 * demo 中需要和侧边栏配置联动，所以使用代理方式获取Config 实例。
	 * 
	 * @return
	 */
	public final static SocializeConfig getSocialConfig(Context context) {
		SocializeConfig config = new SocializeConfig();
		WeakReference<SocializeConfig> ref = new WeakReference<SocializeConfig>(config);
		wCigs.add(ref);
		
		config.supportAppPlatform(context, APP_PLATFORM.FACEBOOK, SUPPORT_FACEBOOK);
		config.supportAppPlatform(context, APP_PLATFORM.TWITTER, SUPPORT_TWITTER);
		config.supportAppPlatform(context, APP_PLATFORM.GOOGLE, SUPPORT_GOOGLE);
		return config;
	}
	
	public synchronized final static void nofifyConfigChange(Context context){
		 Set<WeakReference<SocializeConfig>> deltable = new HashSet<WeakReference<SocializeConfig>>();
		for(WeakReference<SocializeConfig> ref : wCigs){
			SocializeConfig cig = ref.get();
			if(cig != null){
				cig.setPlatforms(getSupportPlatforms());
				
				cig.supportAppPlatform(context, APP_PLATFORM.FACEBOOK, SUPPORT_FACEBOOK);
				cig.supportAppPlatform(context, APP_PLATFORM.TWITTER, SUPPORT_TWITTER);
				cig.supportAppPlatform(context, APP_PLATFORM.GOOGLE, SUPPORT_GOOGLE);
			}else
				deltable.add(ref);
		}
		
		for(WeakReference<SocializeConfig> ref : deltable){
			if(wCigs.contains(ref))
				wCigs.remove(ref);
		}
		
		UMSocialService umSocialService = UMServiceFactory.getUMSocialService("no private config", RequestType.SOCIAL);
		SocializeConfig config = umSocialService.getConfig();
		config.setPlatforms(getSupportPlatforms());
		umSocialService.setGlobalConfig(config);
		
		
	}
	
	public static final SHARE_MEDIA[] getSupportPlatforms(){
		List<SHARE_MEDIA> lists = new ArrayList<SHARE_MEDIA>();
		if(SUPPORT_QZONE)
			lists.add(SHARE_MEDIA.QZONE);
		if(SUPPORT_SINA)
			lists.add(SHARE_MEDIA.SINA);
		if(SUPPORT_TENC)
			lists.add(SHARE_MEDIA.TENCENT);
		if(SUPPORT_RENR)
			lists.add(SHARE_MEDIA.RENREN);
		if(SUPPORT_DOUBAN)
			lists.add(SHARE_MEDIA.DOUBAN);
		
		return lists.toArray(new SHARE_MEDIA[lists.size()]);
		
	}

}
