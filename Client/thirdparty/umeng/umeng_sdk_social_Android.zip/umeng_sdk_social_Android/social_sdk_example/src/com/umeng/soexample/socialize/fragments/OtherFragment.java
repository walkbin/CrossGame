package com.umeng.soexample.socialize.fragments;

import static com.umeng.soexample.socialize.SocialDemoConfig.DESCRIPTOR;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.umeng.socialize.bean.Gender;
import com.umeng.socialize.bean.MultiStatus;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.bean.SnsAccount;
import com.umeng.socialize.bean.SocializeEntity;
import com.umeng.socialize.bean.SocializeUser;
import com.umeng.socialize.bean.UMFriend;
import com.umeng.socialize.controller.RequestType;
import com.umeng.socialize.controller.UMInfoAgent;
import com.umeng.socialize.controller.UMServiceFactory;
import com.umeng.socialize.controller.UMSocialService;
import com.umeng.socialize.controller.listener.SocializeListeners.FetchFriendsListener;
import com.umeng.socialize.controller.listener.SocializeListeners.FetchUserListener;
import com.umeng.socialize.controller.listener.SocializeListeners.MulStatusListener;
import com.umeng.socialize.controller.listener.SocializeListeners.PlatformInfoListener;
import com.umeng.socialize.controller.listener.SocializeListeners.SocializeClientListener;
import com.umeng.soexample.R;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;

public class OtherFragment extends Fragment{

	Context mContext;

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		mContext = activity;
	}

	@Override
	public View onCreateView(	LayoutInflater inflater,
								ViewGroup container,
								Bundle savedInstanceState) {
		View root = inflater.inflate(	R.layout.umeng_example_socialize_othermod_example,
										container,
										false);
		final UMSocialService controller = UMServiceFactory.getUMSocialService(	DESCRIPTOR,
																				RequestType.SOCIAL);

		final TextView textInfo = (TextView) root.findViewById(R.id.textinfo);
		textInfo.setMovementMethod(new ScrollingMovementMethod());

		root.findViewById(R.id.ucenter_info_interface)
			.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					controller.getUserInfo(mContext, new FetchUserListener() {

						@Override
						public void onStart() {

						}

						@Override
						public void onComplete(int status, SocializeUser user) {
							if (status == 200) {
								StringBuilder sb = new StringBuilder();
								sb.append("登录帐号：");
								if (user.loginAccount != null) {
									sb.append(user.loginAccount.getUserName()
												+ "    "
												+ user.loginAccount.getPlatform()
												+ " \r\n");
								}

								sb.append("已授权帐号：\r\n");
								if (user.accounts != null) {
									for (SnsAccount account : user.accounts) {
										sb.append(account.getUserName()
													+ "["
													+ account.getPlatform()
													+ "]\r\n");
									}
								}

								textInfo.setText(sb.toString());
							}
						}
					});
				}
			});

		root.findViewById(R.id.ucenter_button).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				controller.openUserCenter(mContext);
			}
		});

		root.findViewById(R.id.ucenter_native_login).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				boolean login = UMInfoAgent.isLogin(mContext);
				if (login) {
					Toast.makeText(mContext, "已经登录.", Toast.LENGTH_SHORT).show();
				} else
					Toast.makeText(mContext, "还未登录.", Toast.LENGTH_SHORT).show();
			}
		});

		root.findViewById(R.id.ucenter_native_oauth).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				boolean oauthSina = UMInfoAgent.isOauthed(mContext, SHARE_MEDIA.SINA);
				if (oauthSina) {
					Toast.makeText(mContext, "新浪微博已经授权。", Toast.LENGTH_SHORT).show();
				} else
					Toast.makeText(mContext, "新浪微博还未授权", Toast.LENGTH_SHORT).show();
			}
		});

		root.findViewById(R.id.friends_list).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				controller.getFriends(mContext, new FetchFriendsListener() {
					@Override
					public void onStart() {}

					@Override
					public void onComplete(int status, List<UMFriend> friends) {
						StringBuilder sb = new StringBuilder();
						if (status == 200 && friends != null) {
							for (UMFriend friend : friends) {
								sb.append(friend.getName() + "\r\n");
							}
						} else {
							sb.append("statis_code=" + status);
						}
						textInfo.setText(sb.toString());
					}
				}, SHARE_MEDIA.TENCENT);
			}
		});
		/* 查询已授权的平台信息 */
		root.findViewById(R.id.platform_info).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				controller.getPlatformInfo(	mContext,
											SHARE_MEDIA.TENCENT,
											new PlatformInfoListener() {
												@Override
												public void onStart() {

												}

												@Override
												public void onComplete(	int status,
																		Map<String, Object> info) {
													if (status == 200 && info != null) {
														StringBuilder sb = new StringBuilder();
														Set<String> keys = info.keySet();
														for (String kStr : keys) {
															sb.append(kStr
																		+ "="
																		+ info.get(kStr)
																				.toString()
																		+ "\r\n");
														}
														textInfo.setText(sb.toString());
													} else
														textInfo.setText("发生错误：" + status);
												}
											});
			}
		});
		/* 添加好友 */
		root.findViewById(R.id.follow).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				controller.follow(mContext, SHARE_MEDIA.TENCENT, new MulStatusListener() {

					@Override
					public void onStart() {

					}

					@Override
					public void onComplete(	MultiStatus multiStatus,
											int st,
											SocializeEntity entity) {
						if (st == 200) {
							StringBuilder sb = new StringBuilder();
							Map<String, Integer> allStatus = multiStatus.getAllChildren();
							Set<String> keys = allStatus.keySet();
							for (String kStr : keys) {
								sb.append(kStr + "=" + allStatus.get(kStr).toString() + "\r\n");
							}
							textInfo.setText(sb.toString());
						} else
							textInfo.setText("发生错误：" + st);
					}

				},
									"jhenxu",
									"UmengShare");
			}
		});

		/* 更新用户信息 */
		root.findViewById(R.id.update_user).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				SnsAccount snsAccount = new SnsAccount(	"近似神的人",
														Gender.MALE,
														"http://www.fosss.org/Images/ShiJia.jpg",
														"123456789");
				SocializeClientListener listener = new SocializeClientListener() {
					@Override
					public void onStart() {

					}

					@Override
					public void onComplete(int status, SocializeEntity entity) {
						if (status == 200) {
							textInfo.setText("更新用户成功");
						} else
							textInfo.setText("发生错误：" + status);
					}
				};
				controller.login(mContext, snsAccount, listener);
			}
		});

		return root;
	}
}
